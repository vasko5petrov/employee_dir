<?php $__env->startSection('content'); ?>
<div class="container animated fadeInLeft">
    <div class="row">
        <?php if(isset($result) && isset($alert_type)): ?>
            <div class="col s12 m8 offset-m2" hidden>
                <span id="result" value="<?php echo e($result); ?>"><?php echo e($result); ?></span>
            </div>
        <?php endif; ?>
        <div class="col s12 m8 offset-m2">
            <div class="card">
                <div class="card-content">
                    <h5 class="card-title">Edit employee</h5>
                    <div>
                        <?php echo Form::open([
                            'action' => array('EmployeeController@edit', $em->id),
                            'files' => true,
                            'method' => 'post',
                        ]); ?>

                        <div class="row">
                            <div class=" file-field input-field col s12">
                                <div align="center" class="col s12">
                                    <img alt="Employee picture" src="<?php echo e(url('/').'/'.$em->picture); ?>" style="width: 40%;" class="circle responsive-img" id="avatar">
                                </div>
                                <div class="col s12">
                                    <div class="btn orange col s4">
                                        <span>Choose file</span>
                                        <?php echo Form::file('image', ['id'=>'picture']); ?>

                                    </div>
                                    <div class="file-path-wrapper col s8">
                                        <input class="file-path validate" type="text">
                                    </div>
                                    <?php if($errors->has('image')): ?>
                                        <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('image')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="input-field col s12">
                                <input type="hidden" name="em-id" value="<?php echo e($em->id); ?>">
                                <input type="text" class="validate<?php echo e($errors->first('em-name') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('em-name')); ?>" name="em-name" value="<?php echo e($em->name); ?>" id="em-name" autofocus>
                                <label for="em-name">Name</label>
                                <?php if($errors->has('em-name')): ?>
                                    <span class="help-block">
                                    <strong style="color: red;"><?php echo e($errors->first('em-name')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12">
                                <select name="em-gender">
                                    <option value="<?php echo e($em->gender); ?>" selected><?php echo e($em->gender); ?></option>
                                    <?php if($em->gender == ""): ?>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                    <?php elseif($em->gender == "Male"): ?>
                                        <option value="Female">Female</option>
                                    <?php elseif($em->gender = "Female"): ?>
                                        <option value="Male">Male</option>
                                    <?php endif; ?>
                                </select>
                                <label for="em-gender">Gender</label>
                                <?php if($errors->has('em-gender')): ?>
                                    <span class="help-block">
                                    <strong style="color: red;"><?php echo e($errors->first('em-gender')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12">
                                <input type="text" class="validate<?php echo e($errors->first('em-location') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('em-location')); ?>" name="em-location" value="<?php echo e($em->location); ?>" id="em-location" placeholder="">
                                <label for="em-location">Location</label>
                                <?php if($errors->has('em-location')): ?>
                                    <span class="help-block">
                                    <strong style="color: red;"><?php echo e($errors->first('em-location')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12">
                                <input type="text" class="validate<?php echo e($errors->first('em-job-title') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('em-job-title')); ?>" name="em-job-title" value="<?php echo e($em->job_title); ?>" id="em-job-title">
                                <label for="em-job-title">Job title</label>
                                <?php if($errors->has('em-job-title')): ?>
                                    <span class="help-block">
                                    <strong style="color: red;"><?php echo e($errors->first('em-job-title')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12">
                                <input type="email" class="validate<?php echo e($errors->first('em-email') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('em-email')); ?>" name="em-email" value="<?php echo e($em->email); ?>" id="em-email">
                                <label for="em-email">Email</label>
                                <?php if($errors->has('em-email')): ?>
                                    <span class="help-block">
                                    <strong style="color: red;"><?php echo e($errors->first('em-email')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12">
                                <input type="text" class="validate<?php echo e($errors->first('em-phone-number') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('em-phone-number')); ?>" name="em-phone-number" value="<?php echo e($em->phone_number); ?>" id="em-phone-number">
                                <label for="em-phone-number">Phone number</label>
                                <?php if($errors->has('em-phone-number')): ?>
                                    <span class="help-block">
                                    <strong style="color: red;"><?php echo e($errors->first('em-phone-number')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12">
                                <select name="em-department-id" >
                                    <option value=""></option>
                                    <?php foreach($departments as $dp): ?>
                                        <?php if($dp->id == $em->department_id): ?>
                                            <option value="<?php echo e($dp->id); ?>" selected><?php echo e($dp->name); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($dp->id); ?>"><?php echo e($dp->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </select>
                                <label for="em-department-id">Department</label>
                                <?php if($errors->has('em-department-id')): ?>
                                    <span class="help-block">
                                    <strong style="color: red;"><?php echo e($errors->first('em-department-id')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12">
                                <button class="btn waves-effect waves-light green" type="submit">
                                    <i class="material-icons left">save</i>Save
                                </button>
                                <a href="<?php echo e(url('/employee')); ?>" class="btn waves-effect waves-light red">
                                    <i class="material-icons left">cancel</i>Cancel
                                </a>
                            </div>
                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            Materialize.updateTextFields();
            $('select').material_select();

            var msg = $('#result');
            if (msg) {
                Materialize.toast(msg, 5000);
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>