<?php $__env->startSection('content'); ?>
    <style>
        <?php /*Disable search functionality on mobile to use responsive table*/ ?>
        .mobile-hide {
            display: none;
        }

        @media  screen and (min-width: 1150px) {
            .mobile-hide {
                display: block;
            }
        }
        @media  only screen and (min-width: 993px) {
            [id^='action'] {
                visibility: hidden;
            }
        }
    </style>
    <div class="container">
        <h5>Employees</h5>
        <?php if(!Auth::guest()): ?>
            <div class="fixed-action-btn" style="bottom: 45px; right: 24px;">
                <a href="<?php echo e(url('/employee/add')); ?>" class="btn-floating btn-large waves-effect waves-light green" title="Add employee">
                    <i class="large material-icons">add</i>
                </a>
            </div>
        <?php endif; ?>
        <div class="col s12 mobile-hide">
            <a href="#" class="btn waves-effect waves-light right light-blue" title="Search employees" id ="show-search">
                <i class="material-icons left">search</i>Search
            </a>
            <form method="GET", url="employee", class="form navbar-form <?php echo $search ? 'search-ed' : 'search'; ?>" id="search-form" >
                <input type="hidden" name="search" value=1>
                <div class="input-field s12 m6">
                    <input type="text" class="input-sm form-control" name="em-search-name" placeholder="Employee Name" value="<?php echo e($em_search_name); ?>">
                </div>
                <div class="input-field s12 m6">
                    <select class="form-control input-sm" name="em-search-dp">
                        <option value="">Department</option>
                        <?php foreach($departments as $dp): ?>
                            <?php if($dp->id == $em_search_dp): ?>
                                <option value="<?php echo e($dp->id); ?>" selected><?php echo e($dp->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($dp->id); ?>"><?php echo e($dp->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="btn waves-effect waves-light light-blue">
                    <i class="material-icons left">search</i>Search
                </button>
            </form>
            <button class="btn waves-effect waves-light red" id="close-search-form">
                <i class="material-icons left">close</i>Close
            </button>
        </div>

        <?php if(sizeof($employees)): ?>
            <link href="<?php echo e(URL::asset('css/search_form.css')); ?>" rel="stylesheet" >
            <table class="responsive-table sortable bordered striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Department</th>
                        <th>Job Title</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <?php if(!Auth::guest()): ?>
                            <th>Actions</th>
                        <?php endif; ?>
                    </tr>
                <tbody id="tbody">
                <?php foreach($employees as $index=>$em): ?>
                    <tr id="<?php echo e('info-'.$em->id); ?>">
                        <div>
                            <td><?php echo e(($employees->currentPage()-1)*15+$index+1); ?></td>
                            <td><a href="<?php echo e(url('/employee').'/'.$em->id.'/detail'); ?>"><?php echo e($em->name); ?></a></td>
                            <td>
                                <?php if($em->department): ?>
                                    <a href="<?php echo e(url('/department').'/'.$em->department->id.'/detail'); ?>"><?php echo e($em->department->name); ?></a>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($em->job_title); ?></td>
                            <td><?php echo e($em->email); ?></td>
                            <td><?php echo e($em->phone_number); ?></td>
                            <?php if(!Auth::guest()): ?>
                                <td style="width: 100px;">
                                    <div id="confirmDelete" class="modal">
                                        <div class="modal-content">
                                            <p>Are you sure want to delete this?</p>
                                        </div>
                                        <div class="modal-footer">
                                            <button href="#" class="modal-action modal-close waves-effect waves-light btn-flat">Cancel</button>
                                            <button id="confirm" class="modal-action modal-close waves-effect waves-light btn-flat red">Delete</button>
                                        </div>
                                    </div>
                                    <div id="<?php echo e('action-'.$em->id); ?>">
                                    <a href="<?php echo e(url('/employee').'/'.$em->id.'/edit'); ?>" class="btn-floating green" title="Edit" id="<?php echo e('show-edit-'.$em->id); ?>"><i class="material-icons">mode_edit</i></a>
                                    </div>
                                </td>
                            <?php endif; ?>
                        </div>
                    </tr>
                <?php endforeach; ?>
                </tbody>
                </thead>
            </table>
            <center>
                <?php echo $employees->render(); ?>

            </center>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        $('.modal-trigger').leanModal();
        $('select').material_select();

        // Show/hide floating button on scroll
        $(window).scroll(function () {
            var btn  = $('.fixed-action-btn');
            btn.fadeOut();
        });
        $('#tbody').scroll(function () {
            var btn  = $('.fixed-action-btn');
            btn.fadeOut();
        });
        // Scroll end extension
        $.fn.scrollEnd = function(callback, timeout) {
            $(this).scroll(function(){
                var $this = $(this);
                if ($this.data('scrollTimeout')) {
                    clearTimeout($this.data('scrollTimeout'));
                }
                $this.data('scrollTimeout', setTimeout(callback,timeout));
            });
        };
        $(window).scrollEnd(function () {
            var btn  = $('.fixed-action-btn');
            btn.fadeIn();
        }, 1000);
        $('#tbody').scrollEnd(function () {
            var btn  = $('.fixed-action-btn');
            btn.fadeIn();
        }, 1000);

        <!-- Form confirm (yes/ok) handler, submits form -->
        $('#confirmDelete').find('.modal-footer #confirm').on('click', function(){
            $('#deleteForm').submit();
        });

        <!-- Show search form -->
        $(document).ready(function () {
            $('#close-search-form').hide();
            $('#search-form').hide();
            $('#show-search').on('click', function() {
                $('#show-search').hide();
                $('#close-search-form').show();
                $('#search-form').toggle('fast', function() {
                    if ($(this).is(':visible')) {
                        $(this).css('display', 'inline');
                    }
                });
                $('input:text:visible:first').focus();
            });
            $('#close-search-form').on('click', function () {
                $('#close-search-form').hide();
                $('#show-search').show();
                $('#search-form').hide();
            });
        });
        
        <!-- Mouse enter/leave a table row -->
        $('[id^="info-"]').mouseenter(function() {
            id = $(this).attr('id').substr(5);
            $('#action-' + id).css('visibility', 'visible'); 
        }).mouseleave(function() {
            id = $(this).attr('id').substr(5);
            $('#action-' + id).css('visibility', 'hidden'); 
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>