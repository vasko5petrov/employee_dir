<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <?php if(isset($flag)): ?>
            <div class="col-md-12">
                <input id="flag" value="<?php echo e($flag); ?>" type="text" disabled hidden>
            </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 style="color: white">Add employee</h3>
                </div>
                <div class="panel-body" style="padding: 50px;">
                                            <?php /*<link href="<?php echo e(URL::asset('css/avatar.css')); ?>" rel="stylesheet" >*/ ?>
                    <?php echo Form::open([
                        'action' => 'EmployeeController@add',
                        'files' => true,
                        'method' => 'post'
                    ]); ?>

                        <div class="row">
                            <div class="col-md-6">
                            <div class="form-group">
                                <label class="input-group-btn">
                                <span class="btn btn-warning">
                                    Choose image <?php echo Form::file('image', ['id'=>'picture', 'class'=>'form-control-file', 'style'=>'display:none;' ]); ?>

                                </span>
                                </label>
                                <input type="file" style="display: none;" multiple/>
                                <input type="text" class="form-control" style="padding-left: 10px;" readonly/>

                                <?php if($errors->has('image')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('image')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="em-name">Name</label>
                                <input type="text" class="form-control validate<?php echo e($errors->first('em-name') ? ' animated shake' : ''); ?> " data-error="<?php echo e($errors->first('em-name')); ?>" name="em-name" value="<?php echo e(old('em-name')); ?>" id="em-name" autofocus>
                                <?php if($errors->has('em-name')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('em-name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="em-email">Email</label>
                                <input type="email" class="form-control validate<?php echo e($errors->first('em-email') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('em-email')); ?>" name="em-email" value="<?php echo e(old('em-email')); ?>" id="em-email">
                                <?php if($errors->has('em-email')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('em-email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="em-phone-number">Phone number</label>
                                <input type="text" class="form-control validate<?php echo e($errors->first('em-phone-number') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('em-phone-number')); ?>" name="em-phone-number" value="<?php echo e(old('em-phone-number')); ?>" id="em-phone-number">
                                <?php if($errors->has('em-phone-number')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('em-phone-number')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="em-job-title">Job title</label>
                                <input type="text" class="form-control validate<?php echo e($errors->first('em-job-title') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('em-job-title')); ?>" name="em-job-title" value="<?php echo e(old('em-job-title')); ?>" id="em-job-title">
                                <?php if($errors->has('em-job-title')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('em-job-title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            </div>
                            <div class="col-md-6">
                            <div class="form-group">
                                <label for="em-department-id">Department</label>
                                <select name="em-department-id" class="form-control">
                                    <option value=""></option>
                                    <?php if(sizeof($departments)): ?>
                                        <?php foreach($departments as $dp): ?>
                                            <option value="<?php echo e($dp->id); ?>"><?php echo e($dp->name); ?></option>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                                <?php if($errors->has('em-department-id')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('em-department-id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="em-hiringDate">Hiring Date</label>
                                <input type="text" class="datepicker form-control" name="em-hiringDate" value="<?php echo e(old('em-hiringDate')); ?>" id="em-hiringDate" >
                                <?php if($errors->has('em-hiringDate')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('em-hiringDate')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="em-birthday">Birthday</label>
                                <input type="text" class="form-control datepicker birthday" name="em-birthday" value="<?php echo e(old('em-birthday')); ?>" id="em-birthday" >
                                <?php if($errors->has('em-birthday')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('em-birthday')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="em-department-id">Gender</label>
                                <select name="em-gender" class="form-control">
                                    <option value=""></option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                                <?php if($errors->has('em-gender')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('em-gender')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="em-location">Location</label>
                                <input type="text" class="form-control validate<?php echo e($errors->first('em-location') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('em-location')); ?>" name="em-location" value="<?php echo e(old('em-location')); ?>" id="em-location" placeholder="">
                                <?php if($errors->has('em-location')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('em-location')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            </div>
                        </div>
                        <div class="row">
                            
                            <div class="form-group">
                                <button class="btn btn-lg btn-success" type="submit">
                                    <i class="fa fa-save"></i> Save
                                </button>
                                <a href="<?php echo e(url('/employee')); ?>" class="btn btn-lg btn-danger">
                                    <i class="fa fa-times"></i> Cancel
                                </a>
                            </div>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {

            var flag = $('#flag').val();
            var msg = '';
            var type = '';
            if (flag) {
                if (flag == 1) {
                    msg = 'New employee successfully added.';
                    type = 'success';
                }
                else {
                    msg = 'Error. Please try again.';
                    type = 'danger'
                }

                $.bootstrapGrowl(
                    msg,{
                    type: type,
                    delay: 2000,
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>