<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3>Employees
        <?php if(!Auth::guest()): ?>
            <a href="<?php echo e(url('/employee/add')); ?>" style="float: right;" class="btn btn-xl btn-success btn-circle" title="Add employee">
                <i class="fa fa-plus"></i>
            </a>
        <?php endif; ?>
        </h3>
        <hr>
        <div class="row">
            <div class="col-md-9">
            <a data-toggle="collapse" href="#collapse-search-form" class="btn btn-primary btn-block">Search</h4></a>
                <br>
                <div id="collapse-search-form" class="collapse">
                    <form method="GET" url="employee" id="search-form" >
                        <input type="hidden" name="search" value=1>
                        <div class="form-group">
                            <input type="text" class="form-control" name="em-search-name" placeholder="Employee Name" value="<?php echo e($em_search_name); ?>" />
                        </div>
                        <div class="form-group">
                            <select class="form-control" name="em-search-dp">
                                <option value="">All Departments</option>
                                <?php foreach($departments as $dp): ?>
                                    <?php if($dp->id == $em_search_dp): ?>
                                        <option value="<?php echo e($dp->id); ?>" selected><?php echo e($dp->name); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($dp->id); ?>"><?php echo e($dp->name); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-sm btn-primary">
                            <i class="fa fa-search"></i> Search
                        </button>
                        <button class="btn btn-sm btn-danger" data-toggle="collapse" href="#collapse-search-form" id="close-search-form">
                            <i class="fa fa-close"></i> Close
                        </button>
                    </form>
                </div>
            <br>
            <?php if(sizeof($employees)): ?>
                <link href="<?php echo e(URL::asset('css/search_form.css')); ?>" rel="stylesheet" >
                <table class="table tablesorter table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Department</th>
                            <th>Job Title</th>
                            <th>Email</th>
                            <th>Phone Number</th>
                            <?php if(!Auth::guest()): ?>
                                <th class="disabled">Actions</th>
                            <?php endif; ?>
                        </tr>
                    <tbody id="tbody">
                    <?php foreach($employees as $index=>$em): ?>
                        <tr id="<?php echo e('info-'.$em->id); ?>">
                            <div>
                                <td><?php echo e(($employees->currentPage()-1)*15+$index+1); ?></td>
                                <td><a href="<?php echo e(url('/employee').'/'.$em->id.'/detail'); ?>"><?php echo e($em->name); ?></a></td>
                                <td>
                                    <?php if($em->department): ?>
                                        <a href="<?php echo e(url('/department').'/'.$em->department->id.'/detail'); ?>"><?php echo e($em->department->name); ?></a>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($em->job_title); ?></td>
                                <td><?php echo e($em->email); ?></td>
                                <td><?php echo e($em->phone_number); ?></td>
                                <?php if(!Auth::guest()): ?>
                                    <td style="width: 100px;">
                                        <div id="<?php echo e('action-'.$em->id); ?>">
                                            <a href="<?php echo e(url('/employee').'/'.$em->id.'/edit'); ?>" class="btn btn-primary btn-lg btn-circle" title="Edit" id="<?php echo e('show-edit-'.$em->id); ?>"><i class="fa fa-edit"></i></a>
                                        </div>
                                    </td>
                                <?php endif; ?>
                            </div>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                    </thead>
                </table>
                <center>
                    <?php echo $employees->render(); ?>

                </center>
            <?php else: ?>
                <div class="row">
                    <div class="col-md-12">
                        <h5>No Employees found.</h5>
                    </div>
                </div>
            <?php endif; ?>
            </div>
            <?php if(sizeof($employees)): ?>
            <div class="col-md-3">
                <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                  <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingOne">
                      <h4 class="panel-title">
                        <i class="fa fa-user-plus text-primary"></i>
                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            New buddies
                        </a>
                      </h4>
                    </div>
                    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                      <div class="panel-body">
                        <h6>Find out who recently joined the team</h6>
                        <?php if(sizeof($new_em)): ?>
                        <?php foreach($new_em as $key => $nb): ?>
                        <div class="chip well" data-toggle="tooltip" data-placement="top" title="<?php echo e($fnew_em[$key]); ?>">
                            <a href="<?php echo e(url('/employee').'/'.$nb->id.'/detail'); ?>">
                              <img src="<?php echo e(url('/').'/'.$nb->picture); ?>" alt="Person" width="40" height="40">
                              <?php echo e($nb->name); ?>

                            </a>
                        </div>
                        <?php endforeach; ?>
                        <?php else: ?>
                            <p>No recently joined.</p>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingTwo">
                      <h4 class="panel-title">
                        <i class="fa fa-birthday-cake text-warning"></i>
                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            Birthday buddies
                        </a>
                      </h4>
                    </div>
                    <div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
                      <div class="panel-body">
                        <h6>Check out whose birthday is today or up next</h6>
                        <?php if(sizeof($todays_bd)): ?>
                        <p>Today's <?php echo e(sizeof($todays_bd) != 1 ? 'birthdays' : 'birthday'); ?>:</p>
                            <?php foreach($todays_bd as $tbd): ?>
                                <div class="chip well">
                                <a href="<?php echo e(url('/employee').'/'.$tbd->id.'/detail'); ?>">
                                  <img src="<?php echo e(url('/').'/'.$tbd->picture); ?>" alt="Person" width="40" height="40">
                                  <?php echo e($tbd->name); ?>

                                </a>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p>No birthdays today.</p>
                        <?php endif; ?>
                        <?php if(sizeof($next_bd)): ?>
                            <p>Future <?php echo e(sizeof($fnext_bd) != 1 ? 'birthdays' : 'birthday'); ?>:</p>
                            <?php foreach($next_bd as $key => $nbd): ?>
                            <div class="chip well" data-toggle="tooltip" data-placement="top" title="<?php echo e($fnext_bd[$key]); ?>">
                            <a href="<?php echo e(url('/employee').'/'.$nbd->id.'/detail'); ?>">
                              <img src="<?php echo e(url('/').'/'.$nbd->picture); ?>" alt="Person" width="40" height="40">
                              <?php echo e($nbd->name); ?>

                            </a>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p>No future birthdays in the next 7 days.</p>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>