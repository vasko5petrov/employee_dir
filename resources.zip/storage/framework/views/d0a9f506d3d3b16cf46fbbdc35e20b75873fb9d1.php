<?php $__env->startSection('content'); ?>
        
    <div class="container">
        <h3>News & Articles
        <?php if(!Auth::guest()): ?>
            <a href="<?php echo e(url('/posts/add')); ?>" style="float: right;" class="btn btn-xl btn-success btn-circle" title="Add post">
                <i class="fa fa-plus"></i>
            </a>
        <?php endif; ?>
        </h3>
        <hr>
        <div class="row">
            <div class="col-md-9">
            <a data-toggle="collapse" href="#collapse-search-form" class="btn btn-primary btn-block">Search</h4></a>
                <br>
                <div id="collapse-search-form" class="collapse">
                    <form method="GET" url="posts" id="search-form" >
                        <input type="hidden" name="search" value=1>
                        <div class="form-group">
                            <input type="text" class="form-control" name="post-search-title" placeholder="Search by title or content" value="<?php echo e($post_search_title); ?>" />
                        </div>
                        <div class="form-group">
                            <select class="form-control" name="post-search-cat">
                                <option value="">All Categories</option>
                                <?php foreach($categories as $cat): ?>
                                    <?php if($cat->id == $post_search_cat): ?>
                                        <option value="<?php echo e($cat->id); ?>" selected><?php echo e($cat->name); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-sm btn-primary">
                            <i class="fa fa-search"></i> Search
                        </button>
                        <button class="btn btn-sm btn-danger" data-toggle="collapse" href="#collapse-search-form" id="close-search-form">
                            <i class="fa fa-close"></i> Close
                        </button>
                    </form>
                </div>
            <br>
            <?php if(sizeof($posts)): ?>
                <?php foreach($posts as $index=>$post): ?>

                <div class="col-md-12">
                    <div class="panel panel-default">
                        <a href="<?php echo e(url('/post').'/'.$post->id); ?>"><img src="<?php echo e(url('/').'/'.$post->cover_image); ?>" class="responsive-imge" style="width: 100%;"></a>
                        <div class="panel-body">
                            <h3 style="margin-top: 0;"><a href="<?php echo e(url('/post').'/'.$post->id); ?>"><?php echo e($post->title); ?></a></h3>
                            <p><?php echo str_limit($post->body, $limit = 150, $end = '...'); ?></p>
                        </div>
                        <div class="panel-footer">
                            <?php if($categories): ?>
                            <?php foreach($categories as $key=>$cat): ?>
                              <?php if($cat->id == $post->post_category_id): ?>
                                <a style="text-decoration: none;" href="<?php echo e(url('/posts/category/'.$cat->id)); ?>"><span class="label label-<?php echo e($importanceLabels[$cat->importance]); ?>"><?php echo e($cat->name); ?></span></a>
                              <?php endif; ?>
                            <?php endforeach; ?>
                            <?php endif; ?>
                            <?php if(count(json_decode($post->attached_files)) != 0): ?>
                                <a data-toggle="tooltip" title="Attachments" data-placement="right"><i class="fa fa-files-o" style="font-size: 16px"></i></a>
                            <?php endif; ?>
                            <p class="pull-right"><?php echo e($postedOn[$index]); ?></a></p>
                        </div>
                    </div> 
                </div>
                <?php endforeach; ?>
                <center>
                    <?php echo $posts->render(); ?>

                </center>
            <?php else: ?>
                <div class="row">
                    <div class="col-md-9">
                        <h5>No Posts found.</h5>
                    </div>
                </div>
            <?php endif; ?>
            </div>
            <?php if($categories): ?>
            <div class="col-md-3">
                <ul class="list-group">
                    <?php foreach($categories as $key => $cat): ?>
                        <li class="list-group-item"><a href="<?php echo e(url('/posts/category/'.$cat->id)); ?>"><?php echo e($cat->name); ?></a><span class="badge badge-default"><?php echo e($number_posts[$key]); ?></span></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
            
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>