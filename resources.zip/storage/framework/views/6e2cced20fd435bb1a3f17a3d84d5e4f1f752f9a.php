<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <?php if(isset($result) && isset($alert_type)): ?>
            <div class="col-md-12">
                <span id="result" value="<?php echo e($result); ?>"><?php echo e($result); ?></span>
            </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 style="color: white">Edit Event</h3>
                </div>
                <div class="panel-body" style="padding: 50px;">
                                            <?php /*<link href="<?php echo e(URL::asset('css/avatar.css')); ?>" rel="stylesheet" >*/ ?>
                    <?php echo Form::open([
                        'action' => array('EventController@edit', $event->id),
                        'files' => true,
                        'method' => 'post',
                    ]); ?>

                        <div class="row">
                            <div class="form-group">
                                <label for="event-title">Event Title</label>
                                <input type="text" class="form-control validate<?php echo e($errors->first('event-title') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('event-title')); ?>" name="event-title" value="<?php echo e($event->title); ?>" id="event-title" autocomplete="off">
                                <?php if($errors->has('event-title')): ?>
                                    <span class="help-block">
                                    <strong style="color: red;"><?php echo e($errors->first('event-title')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="event-body">Event Description</label>
                                <textarea name="event-body" id="event-body" class="form-control validate<?php echo e($errors->first('event-body') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('event-body')); ?>"><?php echo e($event->description); ?></textarea>
                                <?php if($errors->has('event-body')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('event-body')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="event-dates">Dates</label>
                                <input type="text" class="form-control validate<?php echo e($errors->first('event-dates') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('event-dates')); ?>" name="event-dates" value="<?php echo e($event->start_time . ' - ' . $event->end_time); ?>" id="event-dates" >
                                <?php if($errors->has('event-dates')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('event-dates')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="event-color">Choose Color</label>
                                <datalist id="pallete">
                                  <option>#2196f3</option>
                                  <option>#e51c23</option>
                                  <option>#4caf50</option>
                                  <option>#9c27b0</option>
                                  <option>#ff9800</option>
                                </datalist>
                                <input type="color" class="form-control validate<?php echo e($errors->first('event-color') ? ' animated shake' : ''); ?>" data-error="event-color" name="event-color" list="pallete" value="<?php echo e($event->color); ?>" id="event-color">
                                <?php if($errors->has('event-color')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('event-color')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row">
                            
                            <div class="form-group">
                                <button class="btn btn-lg btn-success" type="submit">
                                    <i class="fa fa-save"></i> Save Article
                                </button>
                                <a href="<?php echo e(url('/events/'.$event->id)); ?>" class="btn btn-lg btn-danger">
                                    <i class="fa fa-times"></i> Cancel
                                </a>
                            </div>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {

            var msg = $('#result');
            if(msg.length >= 1) {
                $.bootstrapGrowl(
                    msg,{
                    type: 'success',
                    delay: 2000,
                });
            }
            $('input[name="event-dates"]').daterangepicker({
                "timePicker": true,
                "timePicker24Hour": true,
                "timePickerIncrement": 15,
                "autoApply": true,
                "locale": {
                    "format": "DD-MM-YYYY HH:mm:ss",
                    "separator": " - ",
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>