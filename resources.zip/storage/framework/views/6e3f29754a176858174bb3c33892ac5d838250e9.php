<?php $__env->startSection('content'); ?>
        
    <div class="container">
        <h3>Events
        <?php if(!Auth::guest()): ?>
            <a href="<?php echo e(url('/event/add')); ?>" style="float: right;" class="btn btn-xl btn-success btn-circle" title="Add event">
                <i class="fa fa-plus"></i>
            </a>
        <?php endif; ?>
        </h3>
        <hr>
        <div class="row">
            <div id='calendar'></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
 $(document).ready(function() {
  
	var base_url = '<?php echo e(url('/')); ?>';
	 
	$('#calendar').fullCalendar({
			weekends: true,
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay',
			},
			weekends: false,
			businessHours: {
			    // days of week. an array of zero-based day of week integers (0=Sunday)
			    dow: [ 1, 2, 3, 4, 5 ], // Monday - Friday

			    start: '09:00', 
			    end: '18:00', 
			},
			editable: false,
			eventLimit: true, // allow "more" link when too many events
			contentHeight: 700,
			isRTL: false,
			events: {
				url: base_url + '/api',
				error: function() {
					alert("cannot load json");
				}
			},
	});


 });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>