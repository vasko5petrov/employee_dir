<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <?php if(isset($flag)): ?>
            <div class="col-md-12">
                <input id="flag" value="<?php echo e($flag); ?>" type="text" disabled hidden>
            </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 style="color: white">Add Event</h3>
                </div>
                <div class="panel-body" style="padding: 50px;">
                                            <?php /*<link href="<?php echo e(URL::asset('css/avatar.css')); ?>" rel="stylesheet" >*/ ?>
                    <?php echo Form::open([
                        'action' => 'EventController@add',
                        'files' => true,
                        'method' => 'post'
                    ]); ?>

                        <div class="row">
                            <div class="form-group">
                                <label for="event-title">Event Title</label>
                                <input type="text" class="form-control validate<?php echo e($errors->first('event-title') ? ' animated shake' : ''); ?> " data-error="<?php echo e($errors->first('event-title')); ?>" name="event-title" value="<?php echo e(old('event-title')); ?>" id="event-title" autocomplete="off">
                                <?php if($errors->has('event-title')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('event-title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="event-body">Event Description</label>
                                <textarea name="event-body" id="event-body" class="form-control validate<?php echo e($errors->first('event-body') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('event-body')); ?>"></textarea>
                                <?php if($errors->has('event-body')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('event-body')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="event-dates">Dates</label>
                                <input type="text" class="form-control" name="event-dates" value="<?php echo e(old('event-dates')); ?>" id="event-dates" >
                                <?php if($errors->has('event-dates')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('event-dates')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="event-color">Choose Color</label>
                                <datalist id="pallete">
                                  <option>#2196f3</option>
                                  <option>#e51c23</option>
                                  <option>#4caf50</option>
                                  <option>#9c27b0</option>
                                  <option>#ff9800</option>
                                </datalist>
                                <input type="color" class="form-control" name="event-color" list="pallete" value="#2196f3" id="event-color">
                                <?php if($errors->has('event-color')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('event-color')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row">
                            
                            <div class="form-group">
                                <button class="btn btn-lg btn-success" type="submit">
                                    <i class="fa fa-save"></i> Create Article
                                </button>
                                <a href="<?php echo e(url('/events/list')); ?>" class="btn btn-lg btn-danger">
                                    <i class="fa fa-times"></i> Cancel
                                </a>
                            </div>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {

            var flag = $('#flag').val();
            var msg = '';
            var type = '';
            if (flag) {
                if (flag == 1) {
                    msg = 'New event successfully created.';
                    type = 'success';
                }
                else {
                    msg = 'Error. Please try again.';
                    type = 'danger'
                }

                $.bootstrapGrowl(
                    msg,{
                    type: type,
                    delay: 2000,
                });
            }
            $('input[name="event-dates"]').daterangepicker({
                "minDate": moment('<?php echo date('Y-m-d G')?>'),
                "timePicker": true,
                "timePicker24Hour": true,
                "timePickerIncrement": 15,
                "autoApply": true,
                "locale": {
                    "format": "DD-MM-YYYY HH:mm:ss",
                    "separator": " - ",
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>