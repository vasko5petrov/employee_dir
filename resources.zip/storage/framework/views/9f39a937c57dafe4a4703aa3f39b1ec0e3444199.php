<?php $__env->startSection('content'); ?>
<div class="container animated fadeInLeft">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 style="color: white">Login</h3>
                </div>
                <div class="panel-body" style="padding: 50px;">
                        <form method="post" action="<?php echo e(url('/login')); ?>">
                            <div class="row">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control validate<?php echo e($errors->first('email') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('email')); ?>" name="email">
                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input type="password" class="form-control validate<?php echo e($errors->first('password') ? ' animated shake' : ''); ?>" name="password">
                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <input type="checkbox" name="remember" id="remember" class="filled-in">
                                    <label for="remember">Remember me</label>
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-success form-control " type="submit" name="submit">Login</button>
                                </div>
                            </div>
                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        Materialize.updateTextFields();
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>