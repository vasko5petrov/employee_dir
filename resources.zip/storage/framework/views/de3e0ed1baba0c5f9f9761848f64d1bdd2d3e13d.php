<?php $__env->startSection('content'); ?>
<div class="">
    <div class="row">
        <?php if(isset($result) && isset($alert_type)): ?>
            <div class="col s12 m8 offset-m2" hidden>
                <span id="result" value="<?php echo e($result); ?>"><?php echo e($result); ?></span>
            </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 style="color: white">Edit Department</h3>
                </div>
                <div class="panel-body" style="padding: 50px;">
                    <div>
                        <?php echo Form::open([
                            'action' => array('DepartmentController@edit', $dp->id),
                            'files' => true,
                            'method' => 'post',
                        ]); ?>

                        <div class="row">
                            <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label for="dp-name">Name</label>
                                    <input type="text" class="form-control validate<?php echo e($errors->first('dp-name') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('dp-name')); ?>" name="dp-name" value="<?php echo e($dp->name); ?>" id="dp-name" autofocus>
                                    <?php if($errors->has('dp-name')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('dp-name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="dp-office-number">Office number</label>
                                    <input type="text" class="form-control validate<?php echo e($errors->first('dp-office-number') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('dp-office-number')); ?>" name="dp-office-number" value="<?php echo e($dp->office_number); ?>" id="dp-office-number">
                                    <?php if($errors->has('dp-office-number')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('dp-office-number')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label>Manager</label>
                                    <select name="dp-manager-id" class="form-control">
                                        <option value="<?php echo e($dp->manager_id); ?>" selected><?php echo e($manager_name); ?></option>
                                        <?php if(sizeof($employees)): ?>
                                            <?php foreach($employees as $em): ?>
                                                <option value="<?php echo e($em->id); ?>"><?php echo e($em->name); ?></option>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                    <?php if($errors->has('dp-manager-id')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('dp-manager-id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                <button class="btn btn-lg btn-success" type="submit">
                                    <i class="fa fa-save"></i> Save
                                </button>
                                <a href="<?php echo e(url('/department')); ?>" class="btn btn-lg btn-danger">
                                    <i class="fa fa-times"></i> Cancel
                                </a>
                            </div>
                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {

            var msg = $('#result');
            if(msg.length >= 1) {
                $.bootstrapGrowl(
                    msg,{
                    type: 'success',
                    delay: 2000,
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>