<?php $__env->startSection('content'); ?>
<div class="container animated fadeInLeft">
    <div class="row">
        <?php if(isset($flag)): ?>
            <div class="col s12 m8 offset-m2">
                <input id="flag" value="<?php echo e($flag); ?>" type="text" disabled hidden>
            </div>
        <?php endif; ?>
        <div class="col s12 m8 offset-m2">
            <div class="card">
                <div class="card-content">
                    <h5 class="card-title">Add employee</h5>
                    <div>
                        <?php /*<link href="<?php echo e(URL::asset('css/avatar.css')); ?>" rel="stylesheet" >*/ ?>
                        <?php echo Form::open([
                            'action' => 'EmployeeController@add',
                            'files' => true,
                            'method' => 'post',
                        ]); ?>

                        <div class="row">
                            <div class=" file-field input-field col s12">
                                <div align="center" class="col s12">
                                    <img alt="Employee picture" src="<?php echo e(url('/uploads/images/icon-user-default.png')); ?>" style="width: 40%;" class="circle responsive-img" id="avatar">
                                </div>
                                <div class="col s12">
                                    <div class="btn orange col s4">
                                        <span>Choose file</span>
                                        <?php echo Form::file('image', ['id'=>'picture']); ?>

                                    </div>
                                    <div class="file-path-wrapper col s8">
                                        <input class="file-path validate" type="text">
                                    </div>
                                    <?php if($errors->has('image')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('image')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="input-field col s12">
                                <input type="text" class="validate<?php echo e($errors->first('em-name') ? ' animated shake' : ''); ?> " data-error="<?php echo e($errors->first('em-name')); ?>" name="em-name" value="<?php echo e(old('em-name')); ?>" id="em-name" autofocus>
                                <label for="em-name">Name</label>
                                <?php if($errors->has('em-name')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('em-name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12">
                                <select name="em-gender" >
                                    <option value=""></option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                                <label for="em-department-id">Gender</label>
                                <?php if($errors->has('em-gender')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('em-gender')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12">
                                <input type="text" class="validate<?php echo e($errors->first('em-location') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('em-location')); ?>" name="em-location" value="<?php echo e(old('em-location')); ?>" id="em-location" placeholder="">
                                <label for="em-location">Location</label>
                                <?php if($errors->has('em-location')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('em-location')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12">
                                <input type="text" class="validate<?php echo e($errors->first('em-job-title') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('em-job-title')); ?>" name="em-job-title" value="<?php echo e(old('em-job-title')); ?>" id="em-job-title">
                                <label for="em-job-title">Job title</label>
                                <?php if($errors->has('em-job-title')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('em-job-title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12">
                                <input type="email" class="validate<?php echo e($errors->first('em-email') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('em-email')); ?>" name="em-email" value="<?php echo e(old('em-email')); ?>" id="em-email">
                                <label for="em-email">Email</label>
                                <?php if($errors->has('em-email')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('em-email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12">
                                <input type="text" class="validate<?php echo e($errors->first('em-phone-number') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('em-phone-number')); ?>" name="em-phone-number" value="<?php echo e(old('em-phone-number')); ?>" id="em-phone-number">
                                <label for="em-phone-number">Phone number</label>
                                <?php if($errors->has('em-phone-number')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('em-phone-number')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12">
                                <select name="em-department-id" >
                                    <option value=""></option>
                                    <?php if(sizeof($departments)): ?>
                                        <?php foreach($departments as $dp): ?>
                                            <option value="<?php echo e($dp->id); ?>"><?php echo e($dp->name); ?></option>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                                <label for="em-department-id">Department</label>
                                <?php if($errors->has('em-department-id')): ?>
                                    <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('em-department-id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s12">
                                <button class="btn waves-effect waves-light green" type="submit">
                                    <i class="material-icons left">save</i>Save
                                </button>
                                <a href="<?php echo e(url('/employee')); ?>" class="btn waves-effect waves-light red">
                                    <i class="material-icons left">cancel</i>Cancel
                                </a>
                            </div>
                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $('select').material_select();

            var flag = $('#flag').val();
            var msg = '';
            if (flag) {
                if (flag == 1) {
                    msg = 'New employee successfully added.';
                }
                else {
                    msg = 'Error. Please try again.';
                }
                Materialize.toast(msg, 5000);
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>