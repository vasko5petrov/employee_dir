<?php $__env->startSection('content'); ?>
<div class="container animated fadeInLeft">
    <div class="row">
        <?php if(isset($result) && isset($alert_type)): ?>
            <div class="col s12 m8 offset-m2" hidden>
                <span id="result" value="<?php echo e($result); ?>"><?php echo e($result); ?></span>
            </div>
        <?php endif; ?>
        <div class="col s12 m8 offset-m2">
            <div class="card">
                <div class="card-content">
                    <h5 class="card-title">Edit department</h5>
                    <div>
                        <?php echo Form::open([
                            'action' => array('DepartmentController@edit', $dp->id),
                            'files' => true,
                            'method' => 'post',
                        ]); ?>

                        <div class="row">
                            <?php echo csrf_field(); ?>

                                <div class="input-field col s12">
                                    <input type="text" class="validate<?php echo e($errors->first('dp-name') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('dp-name')); ?>" name="dp-name" value="<?php echo e($dp->name); ?>" id="dp-name" autofocus>
                                    <label for="dp-name">Name</label>
                                    <?php if($errors->has('dp-name')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('dp-name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="input-field col s12">
                                    <input type="text" class="validate<?php echo e($errors->first('dp-office-number') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('dp-office-number')); ?>" name="dp-office-number" value="<?php echo e($dp->office_number); ?>" id="dp-office-number">
                                    <label for="dp-office-number">Office number</label>
                                    <?php if($errors->has('dp-office-number')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('dp-office-number')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="input-field col s12">
                                    <select name="dp-manager-id">
                                        <option value="<?php echo e($manager_name); ?>" selected><?php echo e($manager_name); ?></option>
                                        <?php if(sizeof($employees)): ?>
                                            <?php foreach($employees as $em): ?>
                                                <option value="<?php echo e($em->id); ?>"><?php echo e($em->name); ?></option>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                    <label>Manager</label>
                                    <?php if($errors->has('dp-manager-id')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('dp-manager-id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="input-field col s12">
                                    <button class="btn waves-effect waves-light green">
                                        <i class="material-icons left">save</i>Save
                                    </button>
                                    <a href="<?php echo e(url('/department')); ?>" class="btn waves-effect waves-light red">
                                        <i class="material-icons left">cancel</i>Cancel
                                    </a>
                                </div>
                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(URL::asset('js/dp_validation.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            $('select').material_select();

            var flag = $('#flag').val();
            var msg = '';
            if (flag) {
                if (flag == 1) {
                    msg = 'New department successfully added.';
                }
                else {
                    msg = 'Error. Please try again.';
                }
                Materialize.toast(msg, 5000);
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>