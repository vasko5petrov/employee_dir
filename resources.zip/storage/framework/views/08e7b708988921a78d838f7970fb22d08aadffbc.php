<?php $__env->startSection('content'); ?>
<div class="container animated fadeInLeft">
    <div class="row">
        <?php if(isset($flag)): ?>
            <div class="col s12 m8 offset-m2">
                <input id="flag" value="<?php echo e($flag); ?>" type="text" disabled hidden>
            </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 style="color: white">Invite new Administrator</h3>
                </div>
                    
                    <div class="panel-body" style="padding: 50px;">
                        <form method="POST" action="<?php echo e(url('/invite/send-invitation')); ?>">
                            <div class="row">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label for="admin-username">Username</label>
                                    <input type="text" class="form-control validate<?php echo e($errors->first('admin-username') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('admin-username')); ?>" name="admin-username" value="<?php echo e(old('admin-username')); ?>" autofocus>
                                    <?php if($errors->has('admin-username')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('admin-username')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="admin-email">Email</label>
                                    <input type="email" class="form-control validate<?php echo e($errors->first('admin-email') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('admin-email')); ?>" name="admin-email" value="<?php echo e(old('admin-email')); ?>">
                                    <?php if($errors->has('admin-email')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('admin-email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success" name="submit">
                                        <i class="fa fa-send"></i> Send
                                    </button>
                                    <a href="<?php echo e(url('/')); ?>" class="btn btn-danger">
                                        <i class="fa fa-times"></i> Cancel
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        var flag = $('#flag').val();
        var msg = '';
        if (flag) {
            if (flag == 1) {
                msg = 'Email sent.';
            }
            else {
                msg = 'Error. Please try again.';
            }
            Materialize.toast(msg, 5000);
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>