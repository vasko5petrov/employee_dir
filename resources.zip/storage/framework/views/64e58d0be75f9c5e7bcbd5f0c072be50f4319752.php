<?php $__env->startSection('content'); ?>
<div class="container animated fadeInUp">
    <div class="row">
        <div class="col-md-9">
            <div class="jumbotron">
                <h1>Welcome</h1>
                <p>
                    This is the <?php echo e(config('app.name', 'Anakatech Family')); ?> office data website. <br>
                            View employees and departments. <br>
                            Check your own employee profile.
                </p>
                <a href="<?php echo e(url('/department')); ?>"><button type="button" class="btn btn-lg btn-default">Departments</button></a>
                <a href="<?php echo e(url('/employee')); ?>"><button type="button" class="btn btn-lg btn-primary">Employees</button></a>
            </div>
            <h4>Event Calendar</h4>
            <div id='calendar'></div>
        </div>
        <div class="col-md-3">
            <h4>Recent News</h4>
            <?php if(count($posts) != 0): ?>
                <ul class="list-group">
                <?php foreach($posts as $index => $post): ?>
                    <div class="panel panel-default">
                        <a href="<?php echo e(url('/post').'/'.$post->id); ?>"><img src="<?php echo e(url('/').'/'.$post->cover_image); ?>" class="responsive-imge" style="width: 100%;"></a>
                        <div class="panel-body">
                          <h6 style="margin: 0px;"><a href="<?php echo e(url('/post').'/'.$post->id); ?>"><?php echo e($post->title); ?></a></h6>
                        </div>
                        <div class="panel-footer clearfix">
                            <?php if(count(json_decode($post->attached_files)) != 0): ?>
                                <a data-toggle="tooltip" title="Attachments" data-placement="right"><i class="fa fa-files-o" style="font-size: 16px"></i></a>
                            <?php endif; ?>
                            <span class="pull-right"><?php echo e($postedOn[$index]); ?></a></span>
                        </div>
                    </div>
                <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
 $(document).ready(function() {
  
    var base_url = '<?php echo e(url('/')); ?>';
     
    $('#calendar').fullCalendar({
            weekends: true,
            header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
        },
            editable: false,
            eventLimit: true, // allow "more" link when too many events
            events: {
            url: base_url + '/api',
            error: function() {
                alert("cannot load json");
            }
        }
    });


 });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>