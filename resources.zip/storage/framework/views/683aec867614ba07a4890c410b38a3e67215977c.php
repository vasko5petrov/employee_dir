<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3 class="card-title">Category details</h3>
        <hr>
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
            <h5>
                <?php echo e($category->name); ?>

            </h5>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 col-md-offset-4 departmentDetails">
                <table class="table">
                    <tbody>
                        <tr>
                            <th>Posts</th>
                            <td><?php echo e($number_posts); ?></td>
                        </tr>
                        <tr>
                            <th>Importance</th>
                            <td><?php echo e($categoriesNames[$category->importance]); ?></td>
                        </tr>
                        <tr>
                            <th>Created at</th>
                            <td><?php echo e($category->created_at); ?></td>
                        </tr>
                        <tr>
                            <th>Updated at</th>
                            <td><?php echo e($category->updated_at); ?></td>
                        </tr>
                    </tbody>
                </table >
                    <table>
                        <tr style="width: 100px;">
                            <?php if(!Auth::guest()): ?>
                            <div id="confirmDelete" class="modal">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="myModalLabel">Are you sure want to delete this?</h4>
                                  </div>
                                  <div class="modal-body">
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                    <form role="form" method="POST" action="<?php echo e(url('/posts/category').'/'.$category->id.'/delete'); ?>" accept-charset="UTF-8" style="display:inline" id="deleteForm">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" class="form-control" name="dp-id" value="<?php echo e($category->id); ?>">
                                        <button class="btn btn-danger" type="submit" title="Delete">Delete Category</button>
                                    </form>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <?php if(!Auth::guest()): ?>
                                <a href="<?php echo e(url('/posts/category').'/'.$category->id.'/edit'); ?>" id="<?php echo e('show-edit-'.$category->id); ?>" class="btn btn-primary btn-circle btn-lg" title="Edit"><i class="fa fa-edit" style=""></i></a>
                                <button class="btn btn-danger btn-lg btn-circle" type="button" data-toggle="modal" data-target="#confirmDelete" title="Delete"><i class="fa fa-trash"></i></button> 
                            <?php endif; ?>
                            <?php endif; ?>
                        </tr>
                    </table>
            </div>
        </div>
        <?php if(sizeof($posts)): ?>
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <?php foreach($posts as $index=>$post): ?>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          <h3 class="panel-title"><a href="<?php echo e(url('/post').'/'.$post->id); ?>"><?php echo e($post->title); ?></a></h3>
                        </div>
                        <a href="<?php echo e(url('/post').'/'.$post->id); ?>"><img src="<?php echo e(url('/').'/'.$post->cover_image); ?>" class="responsive-imge" style="width: 100%;"></a>
                        <div class="panel-body">
                            <p><?php echo str_limit($post->body, $limit = 150, $end = '...'); ?></p>
                        </div>
                        <div class="panel-footer">
                            <?php foreach($categories as $key=>$cat): ?>
                              <?php if($cat->id == $post->post_category_id): ?> 
                                <span class="label label-<?php echo e($importanceLabels[$cat->importance]); ?>"><?php echo e($cat->name); ?></span>
                              <?php endif; ?>
                            <?php endforeach; ?>
                            <?php if(count(json_decode($post->attached_files)) != 0): ?>
                                <a data-toggle="tooltip" title="Attachments" data-placement="right"><i class="fa fa-files-o" style="font-size: 16px"></i></a>
                            <?php endif; ?>
                            <p class="pull-right"><?php echo e($postedOn[$index]); ?></a></p>
                        </div>
                    </div>
                <?php endforeach; ?>
                <center>
                    <?php echo $posts->render(); ?>

                </center>
            </div>
        </div>
            <?php else: ?>
                <div class="row">
                    <div class="col-md-12">
                        <h5>No Posts found.</h5>
                    </div>
                </div>
            <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {

            var msg = $('#result');
            if(msg.length >= 1) {
                $.bootstrapGrowl(
                    msg,{
                    type: 'success',
                    delay: 2000,
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>