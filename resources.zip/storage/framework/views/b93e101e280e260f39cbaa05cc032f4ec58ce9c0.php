<?php $__env->startSection('content'); ?>
<div class="container animated fadeInLeft">
    <div class="row">
        <?php if(isset($result) && isset($alert_type)): ?>
            <div class="col-md-12" hidden>
                <span id="result" value="<?php echo e($result); ?>"><?php echo e($result); ?></span>
            </div>
        <?php endif; ?>
    </div>

    <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 style="color: white">Update Passowrd</h3>
                </div>
                    
                    <div class="panel-body" style="padding: 50px;">
                        <form method="POST" action="<?php echo e(url('/update/password')); ?>">
                            <div class="row">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label for="current_password">Current password</label>
                                    <input type="password" class="form-control validate<?php echo e($errors->first('current_password') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('current_password')); ?>" name="current_password" value="<?php echo e(old('current_password')); ?>" autofocus>
                                    <?php if($errors->has('current_password')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('current_password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="new_password">New password</label>
                                    <input type="password" class="form-control validate<?php echo e($errors->first('new_password') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('new_password')); ?>" name="new_password" value="<?php echo e(old('new_password')); ?>">
                                    <?php if($errors->has('new_password')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('new_password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="password_confirm">Confirm password</label>
                                    <input type="password" class="form-control validate<?php echo e($errors->first('password_confirm') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('password_confirm')); ?>" name="password_confirm" value="<?php echo e(old('password_confirm')); ?>">
                                    <?php if($errors->has('password_confirm')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('password_confirm')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-success" type="submit" name="submit">
                                        <i class="fa fa-save"></i> Save
                                    </button>
                                    <a href="<?php echo e(url('/')); ?>" type="button" class="btn btn-danger">
                                        <i class="fa fa-times"></i> Cancel
                                    </a>
                                </div>
                            </div>
                        </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        var msg = $('#result');
        if (msg) {
            Materialize.toast(msg, 5000);
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>