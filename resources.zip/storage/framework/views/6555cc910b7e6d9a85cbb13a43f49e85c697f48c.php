<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col s12">
                <div class="card">
                    <div class="card-content">
                        <h5 class="card-title">
                            <a href="<?php echo e(url('/department').'/'.$dp->id.'/detail'); ?>"><?php echo e($dp->name); ?></a>
                            <span class="chip right"><?php echo e(sizeof($employees)); ?> <?php echo e(sizeof($employees) != 1 ? 'employees' : 'employee'); ?></span>
                        </h5>
                        <?php if(sizeof($employees)): ?>
                            <table class="responsive-table sortable">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Job Title</th>
                                    <th>Email</th>
                                    <th>Phone Number</th>
                                </tr>
                                <tbody>
                                <?php foreach($employees as $index=>$em): ?>
                                    <tr>
                                        <td><?php echo e(($employees->currentPage()-1)*10+$index+1); ?></td>
                                        <td><a href="<?php echo e(url('/employee').'/'.$em->id.'/detail'); ?>"><?php echo e($em->name); ?></a></td>
                                        <td><?php echo e($em->job_title); ?></td>
                                        <td><?php echo e($em->email); ?></td>
                                        <td><?php echo e($em->phone_number); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                                </thead>
                            </table>
                            <center>
                                <?php echo $employees->render(); ?>

                            </center>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>