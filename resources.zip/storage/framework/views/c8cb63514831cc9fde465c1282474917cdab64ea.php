<?php $__env->startSection('content'); ?>
<div class="container animated fadeInLeft">
    <div class="row">
        <?php if(isset($result) && isset($alert_type)): ?>
            <div class="col s12 m8 offset-m2" hidden>
                <span id="result" value="<?php echo e($result); ?>"><?php echo e($result); ?></span>
            </div>
        <?php endif; ?>
        <div class="col s12 m8 offset-m2">
            <div class="card">
                <div class="card-content">
                    <h5 class="card-title">Update password</h5>
                    <div>
                        <form method="POST" action="<?php echo e(url('/update/password')); ?>">
                            <div class="row">
                                <?php echo csrf_field(); ?>

                                <div class="input-field col s12">
                                    <input type="password" class="validate<?php echo e($errors->first('current_password') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('current_password')); ?>" name="current_password" value="<?php echo e(old('current_password')); ?>" autofocus>
                                    <label for="current_password">Current password</label>
                                    <?php if($errors->has('current_password')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('current_password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="input-field col s12">
                                    <input type="password" class="validate<?php echo e($errors->first('new_password') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('new_password')); ?>" name="new_password" value="<?php echo e(old('new_password')); ?>">
                                    <label for="new_password">New password</label>
                                    <?php if($errors->has('new_password')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('new_password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="input-field col s12">
                                    <input type="password" class="validate<?php echo e($errors->first('password_confirm') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('password_confirm')); ?>" name="password_confirm" value="<?php echo e(old('password_confirm')); ?>">
                                    <label for="password_confirm">Confirm password</label>
                                    <?php if($errors->has('password_confirm')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('password_confirm')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="input-field col s12">
                                    <button class="btn waves-effect waves-light" type="submit" name="submit">
                                        <i class="material-icons left">save</i>Save
                                    </button>
                                    <a href="<?php echo e(url('/')); ?>" type="button" class="btn waves-effect waves-light">
                                        <i class="material-icons left">cancel</i>Cancel
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        var msg = $('#result');
        if (msg) {
            Materialize.toast(msg, 5000);
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>