<?php $__env->startSection('content'); ?>
<div class="container animated fadeInLeft">
    <div class="row">
        <div class="col s12 m8 offset-m2">
            <div class="card">
                <div class="card-content">
                    <h5 class="card-title"><strong>Login</strong></h5>
                    <div>
                        <form method="post" action="<?php echo e(url('/login')); ?>">
                            <div class="row">
                                <?php echo csrf_field(); ?>

                                <div class="input-field col s12">
                                    <input type="email" class="validate<?php echo e($errors->first('email') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('email')); ?>" name="email">
                                    <label for="email">Email</label>
                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="input-field col s12">
                                    <input type="password" class="validate<?php echo e($errors->first('password') ? ' animated shake' : ''); ?>" name="password">
                                    <label for="password">Password</label>
                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                        <strong style="color: red;"><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <div class="input-field col s12">
                                    <input type="checkbox" name="remember" id="remember" class="filled-in">
                                    <label for="remember">Remember me</label>
                                </div>
                                <div class="input-field col s12">
                                    <button class="btn waves-effect waves-light" type="submit" name="submit">Login</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        Materialize.updateTextFields();
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>