<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 class="card-title">Manage events</h3>
    <hr>
    <div class="row">
    <div class="col-md-12">
        <?php if(sizeof($events)): ?>
                <link href="<?php echo e(URL::asset('css/search_form.css')); ?>" rel="stylesheet" >
                <table class="table tablesorter table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Event's Title</th>
                            <th>Start</th>
                            <th>End</th>
                            <?php if(!Auth::guest()): ?>
                                <th class="disabled">Actions</th>
                            <?php endif; ?>
                        </tr>
                    <tbody id="tbody">
                    <?php foreach($events as $index=>$ev): ?>
                        <tr id="<?php echo e('info-'.$ev->id); ?>">
                            <div>
                                <td><?php echo e($index+1); ?></td>
                                <td><a href="<?php echo e(url('/events').'/'.$ev->id); ?>"><?php echo e($ev->name); ?></a></td>
                                <td><?php echo e($ev->start_time); ?></td>
                                <td><?php echo e($ev->end_time); ?></td>
                                <?php if(!Auth::guest()): ?>
                                    <td style="width: 100px;">
                                        <div id="<?php echo e('action-'.$ev->id); ?>">
                                            <a href="<?php echo e(url('/event').'/'.$ev->id.'/edit'); ?>" class="btn btn-primary btn-lg btn-circle" title="Edit" id="<?php echo e('show-edit-'.$ev->id); ?>"><i class="fa fa-edit"></i></a>
                                        </div>
                                    </td>
                                <?php endif; ?>
                            </div>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                    </thead>
                </table>
            <?php else: ?>
                <div class="row">
                    <div class="col-md-12">
                        <h5>No Events found.</h5>
                    </div>
                </div>
            <?php endif; ?>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>