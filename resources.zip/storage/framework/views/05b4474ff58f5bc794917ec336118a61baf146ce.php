<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="_token" content="<?php echo csrf_token(); ?>"/>

    <title><?php echo e(config('app.name', 'Anakatech Team')); ?></title>

    <!-- Fonts -->
    <?php /*<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.css" rel='stylesheet' type='text/css'>*/ ?>
    <link href="<?php echo e(url('/font-awesome/css/font-awesome.min.css')); ?>" rel='stylesheet' type='text/css'>
    <?php /*<link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700" rel='stylesheet' type='text/css'>*/ ?>
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- Styles -->
    <?php /*<link href="<?php echo e(url('/css/bootstrap-flatly.min.css')); ?>" rel="stylesheet" type="text/css">*/ ?>
    <link href="<?php echo e(url('/css/animate.css')); ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="<?php echo e(url('/materialize/css/materialize.min.css')); ?>" type="text/css">
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB9Yah75rDjdUSwHjPt420XKmH1RLiSMA4&libraries=places&sensor=false&language=en"></script>
    <?php /* <link href="<?php echo e(elixir('css/app.css')); ?>" rel="stylesheet"> */ ?>
    <?php /*<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.6/css/materialize.min.css">*/ ?>

    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }

        .fa-btn {
            margin-right: 6px;
        }
        table caption {
            background-color: #777;
            color: white;
        }
        .employeeDetails table th {
            width: 160px;
        }
        #menu-dropdown.dropdown-content {
            min-width: 200px;
            margin-top: 70px;
        }
    </style>
</head>
<body id="app-layout">
    <nav>
        <div class="nav-wrapper light-blue">
            <a class="brand-logo left white" href="<?php echo e(url('/')); ?>" style="padding: 0 10px;">
                <!-- Branding Image -->
                <?php /*<img src="<?php echo e(URL::asset('logo.png')); ?>" width="24" style="vertical-align: middle; display: inline-block;">*/ ?>
                <?php /*<div style="vertical-align: middle; display: inline-block;">Employee Directory</div>*/ ?>
                <?php /* config('app.name', 'Anakatech Team') */ ?>
                <img src="<?php echo e(URL::asset('website-logo.png')); ?>" width="200" style="vertical-align: middle; display: inline-block; margin-top: -10px;">
            </a>
            <a href="#" data-activates="nav-mobile" class="button-collapse">
                <i class="material-icons">menu</i>
            </a>

            <!-- Left Side Of Navbar -->
            <ul class="left hide-on-med-and-down" style="margin-left: 220px">
                <li><a href="<?php echo e(url('/department')); ?>">Departments</a></li>
                <li><a href="<?php echo e(url('/employee')); ?>">Employees</a></li>
            </ul>
            <ul class="right hide-on-med-and-down">
                <?php if(Auth::guest()): ?>
                    <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                <?php else: ?>
                    <li>
                        <a href="#" class="dropdown-button"  data-activates="menu-dropdown">
                            <span style="width: 50px;"><?php echo e(Auth::user()->username); ?><i class="material-icons right">arrow_drop_down</i></span>
                        </a>
                        <ul id="menu-dropdown" class="dropdown-content">
                            <li><a href="<?php echo e(url('/employee/add')); ?>" class="black-text"><i class="tiny material-icons left" style="font-size: 18px;">add</i>Add Employee</a></li>
                            <hr>
                            <li><a href="<?php echo e(url('/update/password')); ?>" class="black-text"><i class="tiny material-icons left" style="font-size: 18px;">mode_edit</i>Edit password</a></li>
                            <?php if(Auth::user()->email == 'example@gmail.com'): ?>
                                <li><a href="<?php echo e(url('/invite')); ?>" class="black-text"><i class="tiny material-icons left" style="font-size: 18px;">email</i>Invite admin</a></li>
                            <?php endif; ?>
                            <li><a href="<?php echo e(url('/logout')); ?>" class="black-text"><i class="tiny material-icons left" style="font-size: 18px;">chevron_left</i>Logout</a></li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>

            <?php /*Mobile menu*/ ?>
            <ul id="nav-mobile" class="side-nav">
                <li><a href="<?php echo e(url('/department')); ?>">Departments</a></li>
                <li><a href="<?php echo e(url('/employee')); ?>">Employees</a></li>
                <?php if(Auth::guest()): ?>
                    <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                <?php else: ?>
                    <li>
                        <a href="#" class="dropdown-button"  data-activates="mobile-menu-dropdown">
                            <span style="width: 50px;"><?php echo e(Auth::user()->username); ?><i class="material-icons right">arrow_drop_down</i></span>
                        </a>
                    </li>
                    <ul id="mobile-menu-dropdown" class="dropdown-content">
                        <li><a href="<?php echo e(url('/update/password')); ?>"><i class="tiny material-icons left" style="font-size: 18px;">mode_edit</i>Edit password</a></li>
                        <?php if(Auth::user()->email == 'example@gmail.com'): ?>
                            <li><a href="<?php echo e(url('/invite')); ?>"><i class="tiny material-icons left" style="font-size: 18px;">email</i>Invite admin</a></li>
                        <?php endif; ?>
                        <li><a href="<?php echo e(url('/logout')); ?>"><i class="tiny material-icons left" style="font-size: 18px;">chevron_left</i>Logout</a></li>
                    </ul>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

    <!-- JavaScripts -->
    <script src="<?php echo e(url('/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(url('/materialize/js/materialize.js')); ?>"></script>
    <script src="<?php echo e(url('/js/googleAutocomplete.js')); ?>"></script>
    <script src="<?php echo e(url('/js/jquery.tablesorter.js')); ?>"></script>
    <?php /*<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.js"></script>*/ ?>
    <?php /*<script src="<?php echo e(url('/js/bootstrap.min.js')); ?>"></script>*/ ?>
    
    <script type="text/javascript">
        $(document).ready(function () {
            $(".button-collapse").sideNav();
            $(".dropdown-button").dropdown();
            $(function() {
                $.ajaxSetup({
                    headers: {
                        'X-XSRF-Token': $('meta[name="_token"]').attr('content')
                    }
                });
            });
            $(".sortable").tablesorter();

            $('.modal-trigger').leanModal();
            $('#confirmDelete').find('.modal-footer #confirm').on('click', function(){
                $('#deleteForm').submit();
            });
        });
    </script>

    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
