<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <?php if(isset($result) && isset($alert_type)): ?>
            <div class="col s12 m8 offset-m2" hidden>
                <span id="result" value="<?php echo e($result); ?>"><?php echo e($result); ?></span>
            </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 style="color: white">Edit Category</h3>
                </div>
                <div class="panel-body" style="padding: 50px;">
                    <div>
                        <?php echo Form::open([
                                        'action' => array('PostsCategoriesController@edit', $pcat->id),
                                        'files' => true,
                                        'method' => 'post',
                                    ]); ?>

                                    <div class="row">
                                    <div class="col-md-12">
                                        <?php echo csrf_field(); ?>

                                            <div class="form-group">
                                                <label for="new-category-name">Name</label>
                                                <input type="text" class="form-control validate<?php echo e($errors->first('new-category-name') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('new-category-name')); ?>" name="new-category-name" value="<?php echo e($pcat->name); ?>" id="new-category-name" autofocus>
                                                <?php if($errors->has('new-category-name')): ?>
                                                    <span class="help-block">
                                                        <strong style="color: red;"><?php echo e($errors->first('new-category-name')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="new-category-importance">Importance</label>
                                                <select name="new-category-importance" class="form-control  validate<?php echo e($errors->first('new-category-importance') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('new-category-importance')); ?>" id="new-category-importance">
                                                    <option value="" disabled selected>Choose importance</option>
                                                    <?php foreach($categoriesNames as $key => $pcatName): ?>
                                                    <?php if($pcat->importance == $key): ?>
                                                        <option value="<?php echo e($key); ?>" selected><?php echo e($pcatName); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($key); ?>"><?php echo e($pcatName); ?></option>
                                                    <?php endif; ?>
                                                    <?php endforeach; ?>
                                                </select>
                                                <?php if($errors->has('new-category-importance')): ?>
                                                    <span class="help-block">
                                                    <strong style="color: red;"><?php echo e($errors->first('new-category-importance')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <button class="btn btn-lg btn-success" type="submit">
                                                    <i class="fa fa-save"></i> Save
                                                </button>
                                                <a href="<?php echo e(url('/posts/categories')); ?>" class="btn btn-lg btn-danger">
                                                    <i class="fa fa-times"></i> Cancel
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {

            var msg = $('#result');
            if(msg.length >= 1) {
                $.bootstrapGrowl(
                    msg,{
                    type: 'success',
                    delay: 2000,
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>