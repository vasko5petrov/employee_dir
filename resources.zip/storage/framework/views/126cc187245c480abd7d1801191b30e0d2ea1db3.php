<?php $__env->startSection('content'); ?>
<div class="container animated fadeInLeft">
    <div class="row">
        <?php if(isset($flag)): ?>
            <div class="col s12 m8 offset-m2">
                <input id="flag" value="<?php echo e($flag); ?>" type="text" disabled hidden>
            </div>
        <?php endif; ?>
        <div class="col s12 m8 offset-m2">
            <div class="card">
                <div class="card-content">
                    <h5 class="card-title">Invite new administrator</h5>
                    <div>
                        <form method="POST" action="<?php echo e(url('/invite/send-invitation')); ?>">
                            <div class="row">
                                <?php echo csrf_field(); ?>

                                <div class="input-field col s12">
                                    <input type="text" class="validate<?php echo e($errors->first('admin-username') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('admin-username')); ?>" name="admin-username" value="<?php echo e(old('admin-username')); ?>" autofocus>
                                    <label for="admin-username">Username</label>
                                    <?php if($errors->has('admin-username')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('admin-username')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="input-field col s12">
                                    <input type="email" class="validate<?php echo e($errors->first('admin-email') ? ' animated shake' : ''); ?>" data-error="<?php echo e($errors->first('admin-email')); ?>" name="admin-email" value="<?php echo e(old('admin-email')); ?>">
                                    <label for="admin-email">Email</label>
                                    <?php if($errors->has('admin-email')): ?>
                                        <span class="help-block">
                                            <strong style="color: red;"><?php echo e($errors->first('admin-email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="input-field col s12">
                                    <button type="submit" class="btn waves-effect waves-light" name="submit">
                                        <i class="material-icons left">send</i>Send
                                    </button>
                                    <a href="<?php echo e(url('/')); ?>" class="btn waves-effect waves-light">
                                        <i class="material-icons left">cancel</i>Cancel
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        var flag = $('#flag').val();
        var msg = '';
        if (flag) {
            if (flag == 1) {
                msg = 'Email sent.';
            }
            else {
                msg = 'Error. Please try again.';
            }
            Materialize.toast(msg, 5000);
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>