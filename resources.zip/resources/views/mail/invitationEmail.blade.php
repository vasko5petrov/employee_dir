<html>
    <body>
        <h3>Congratulations!</h3>
        <p>
            You are the chosen one to become a member of Employee Directory's administrator team.<br/>
            Join us here: {{$link}}<br/>
            --------<br/>
            Your account information:<br/>
            <strong>Email:</strong> {{$email}}<br/>
            <strong>Password:</strong> {{$password}}<br/><br/>
            *Note: You must update your own password on first login<br/><br/>

            Best,<br/>
            Employee Directory Team<br/>
        </p>
    </body>
</html>